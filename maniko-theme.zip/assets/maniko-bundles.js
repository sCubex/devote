class FeaturedImageSection extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.gridSettings = JSON.parse(this.getAttribute("grid-settings"));
        console.log(this.gridSettings)
        
        this.shadowRoot.innerHTML = `
            <style>
                :host{
                    width: auto;
                    border-radius: 1rem;
                    padding-bottom: 3.125rem;
                    padding-top: 3.125rem;
                    padding-left: 2.938rem;
                    padding-right: 2.938rem;
                    background: #fefe09;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    box-sizing: border-box;
                    margin-right: 0;
                }
                img{
                    width: auto;
                    height: 100%;
                    object-fit: contain;
                    border-radius: 5px;
                    max-height: 18.75rem;
                    box-sizing: border-box;
                }
            </style>
            <img alt="null" src="https://drinkolipop.com/cdn/shop/products/Olipop_BC_Can_front_022323.png?v=1677178688&amp;width=600" />
            `;
    }
}

customElements.define("featured-image-section", FeaturedImageSection);/* create custom element */

class ProductFeature extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.gridSettings = JSON.parse(this.getAttribute("grid-settings"));
        console.log(this.gridSettings)
        this.imageSrc = this.getAttribute("image-src");
        this.imageAlt = this.getAttribute("image-alt");
        this.featureText = this.getAttribute("feature-text");

        
        this.shadowRoot.innerHTML = `
            <style>
            :host{
                
                background: #f0f0f0;
                box-sizing: border-box;
                padding-bottom: 1.5rem;
                padding-top: 1.5rem;
                padding-left: 1.875rem;
                padding-right: 1.875rem;
                padding: 1.5rem 1.875rem;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                border-radius: 1rem;
                background: #fefe09;
            }
                .outer{
                    padding: 20px; 
                    }
            img{
                width: 2rem;
                height: 2rem;
                box-sizing: border-box;
            }
            </style>
            <!-- <div class="outer"> -->
            <img alt="null" src="https://cld.accentuate.io/7401847029919/1654091085072/value-prop---9g-of-fiber.svg?v=0&amp;options=w_64,h_64">
            <span class="tw-whitespace-nowrap tw-pt-3 tw-font-body tw-text-xs tw-font-bold lg:tw-text-xl" style="font-size: 1.25rem;line-height: 1.75rem;font-weight: 700;padding-top: .75rem;">High Fiber</span>
            <!-- </div> -->
            `;
    }
}

customElements.define("product-feature", ProductFeature);


class productFeaturesSection extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.gridSettings = JSON.parse(this.getAttribute("grid-settings"));
        console.log(this.gridSettings)
        
        this.shadowRoot.innerHTML = `
            
            <style>
            :host{
                display: flex;
                flex-flow: column;
                width: auto;
                height: auto;
                gap: 20px;
                box-sizing: border-box;
            }
            [product-image__container]{
                display: grid;
                grid-template-columns: auto minmax(auto,140px);
                gap: 1rem;
            }
            img{
                width: 100%;
                height: 100%;
                object-fit: cover;
                border-radius: 5px;
            }
            </style>
            <slot></slot>
            
            
            `;
    }
}

customElements.define("product-features-section", productFeaturesSection);

class productGroup extends HTMLElement {
  constructor() {
    super();
    this._data = {};
    this._value = 0;

    this.data = this.json(this);

    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
        <style>
          *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          :root{
            --aspect-ratio:0.8;
          }
          .container {
            display: grid;
            grid-template-columns: repeat(auto-fit,minmax(auto,125px))
          }
          div[data-title]{
            font-size: 0.85em;
            text-align: center;
            margin-top: 4px;

          }
          button {
            padding: 10px 20px;
            background-color: #000;
            color: #fff;
            border: none;
            cursor: pointer;
          }
          div[data-placeholder=""]{
            position: relative;
            width: 100%;
            height: 100%;
            object-fit: cover;
            border: 1px dashed currentColor;
            border-radius: 5px;
            background: #f5f5f5;
            transition: all .2s cubic-bezier(.4,0,.2,1);
            z-index: 0;
            min-height: 190px;
            
            
          }
          [data-product-group-container]{
            position: relative;
            display: flex;
  flex-direction: column;
          }
          [data-placeholder] img{
              width: 100%;
              height: 100%;
              object-fit: cover;
          }
          div[data-placeholder=""]::after{
            content: "";
            background-image: var(--img-url);
            background-size: cover;
            position: absolute;
            background-position: center;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            overflow: hidden;
          }
          [data-toggle] {
          --width: 40px;
            top: 50%;
            left: 50%;
            padding: calc(var(--width) * 33 / 100);
            border-radius: 100%;
            transform: translate(-50%,-50%) rotate(45deg);
            box-shadow: none;
            position: absolute;
            width: 40px;
            height: auto;
            z-index: 9;
            background: #fff;
          }
            [data-toggle][remove] {
            --width: 30px;
            top: -10px;
            right: -10px;
            left: auto;
            padding: calc(var(--width) * 30 / 100);
            border-radius: 100%;
            box-shadow: none;
            
            position: absolute;
            width: 30px;
            height: auto;
            z-index: 9;
            background: #fff;
            box-shadow: 1px 1px 10px #c3c3c3;
            border: 2px solid #c3c3c3;
            transform: none;
        }
        </style>
        
        <div data-product-group-container class="product-group-container" data-item=${this.data.title}>
          <svg data-toggle viewBox="0 0 20 20"><path d="M18.75 18.75L1.25 1.25M18.75 1.25L1.25 18.75" stroke="#121212" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
          <div data-placeholder=""></div>
          <div data-title=${this.data.title}></div>
        </div>`;

    
    this.shadowRoot.querySelector("[data-product-group-container]").addEventListener("click", (e) => {
      const target = e.target.shadowRoot || e.target;
      const isToggleClicked = target.matches("svg");
      if (isToggleClicked) {
        const title = e.target.parentElement.dataset.item;
        
        this.shadowRoot.dispatchEvent(
          new CustomEvent("handle-toggle-click", {
            detail: {
              target: target,
              title: title,
            },
          })
        );
      } else {
        
        const toggle = this.shadowRoot.querySelector("[data-toggle]");
        if (toggle.hasAttribute("remove")) {
            toggle.style.setProperty("display", "block");
            toggle.removeAttribute("remove");
            toggle.nextElementSibling.innerHTML = "";
        } else {
          //toggle.style.setProperty("display", "none");
          //toggle.setAttribute("remove", "");
          const variantsModal = document.querySelector("variants-Modal");
          variantsModal.setAttribute("open", "");
          variantsModal.setAttribute("title", this.data.title);
          //dataTitle = e.detail.title;
        }

        this.shadowRoot.dispatchEvent(
          new CustomEvent("product-selected", {
            detail: {
              callback: this.data.callback,
              title: this.data.title,
            },
          })
        );
      }
    });

    this.shadowRoot.addEventListener("handle-toggle-click", (e) => {
      const target = e.detail?.target;
      const title = e.detail?.title;
      
      if (target.hasAttribute("remove")) {
        target.style.setProperty("display", "block");
        target.removeAttribute("remove");
        target.nextElementSibling.innerHTML = "";
      } else {
        
        //target.style.setProperty("display", "none");
        //target.setAttribute("remove", "");
        const variantsModal = document.querySelector("variants-Modal");
        variantsModal.setAttribute("open", "");
        variantsModal.setAttribute("title", title);
        //dataTitle = e.detail.title;
        this.shadowRoot.dispatchEvent(
          new CustomEvent("product-selected", {
            detail: {
              callback: this.data.callback,
              title: this.data.title,
            },
          })
        );
      }
    });
    //   this.shadowRoot.querySelector("[data-toggle]").addEventListener("click", (e) => {
    //     e.stopPropagation();
    //     const target = e.target;
    //     const title = e.target.parentElement.dataset.item
    //       if (target.hasAttribute("remove")) {
    //         debugger;
    //         target.removeAttribute("remove");
    //         target.nextElementSibling.innerHTML = "";
    //       } else {
    //         debugger;
    //         target.setAttribute("remove", "");
    //         const variantsModal =  document.querySelector("variants-Modal")
    //         variantsModal.setAttribute("open", "");
    //         variantsModal.setAttribute("title", title);
    //         //dataTitle = e.detail.title;
    //         this.shadowRoot.dispatchEvent(
    //             new CustomEvent("product-selected", {
    //               detail: {
    //                   callback:this.data.callback,
    //                   title: this.data.title,
    //               }
    //             })
    //           );
    //       }

    // });
  }

  connectedCallback() {
    //this.shadowRoot.querySelector("[data-placeholder]").style.setProperty("--img-url", `url(${this.data.callback[0].image})`);
    this.data = this.json(this);
    const titleElement = this.shadowRoot.querySelector("[data-title]");
    titleElement.innerText = this.data.title;
    titleElement.setAttribute("data-title", this.data.title);

    const productGroupContainer = this.shadowRoot.querySelector("[data-product-group-container]");
    productGroupContainer.setAttribute("data-item", this.data.title);

    //console.log("Data", this.data);
  }

  get json() {
    return (scope) => JSON.parse(scope.querySelector(':scope > [type="application/json"]')?.innerText || "{}");
  }
}

customElements.define("product-group", productGroup);

class productGroupContainer extends HTMLElement {
    constructor() {
      super();
      this.bundleCount = this.getAttribute("bundle-count");
      this.attachShadow({ mode: "open" });
      this.shadowRoot.innerHTML = `
        <style>
          :host {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(auto, 125px));
            gap: 15px;
            cursor: pointer;
          }
        </style>
        <slot></slot>
      `;
    }
}

customElements.define("product-group-container", productGroupContainer);/* Create a custom element to display a product image */

class ProductImage extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.gridColumnStart = this.getAttribute("grid-col-start");
        this.colSpan = this.getAttribute("col-span");
        this.gridRowStart = this.getAttribute("grid-row-start");
        this.rowSpan = this.getAttribute("row-span");
        
        this.shadowRoot.innerHTML = `
            <style>
            :host{
                width: auto;
                border-radius: 1rem;
                padding-bottom: 3.125rem;
                padding-top: 3.125rem;
                padding-left: 2.938rem;
                padding-right: 2.938rem;
                background: #fefe09;
                display: flex;
                justify-content: center;
                align-items: center;
                box-sizing: border-box;
                margin-right: 0;
            }
            [product-image__container]{
                display: grid;
                grid-template-columns: auto minmax(auto,140px);
                gap: 1rem;
            }
            img{
                width: 100%;
                height: 100%;
                object-fit: cover;
                border-radius: 5px;
                max-height: 18.75rem;
                box-sizing: border-box;
            }
            </style>
            
            <img src="${this.getAttribute("src")}" alt="${this.getAttribute("alt")}" />
            `;
        }

        connectedCallback() {
            this.style.gridRow = `${this.gridRowStart} / span ${this.rowSpan}`;
        }

        set src(value) {
            this.setAttribute("src", value);
        }

        get src() {
            return this.getAttribute("src");
        }
       
}
    
customElements.define("product-image", ProductImage);

class ProductImageContainer extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        console.log("OHYEAH", this.getAttribute("grid-settings"));  
        this.gridSettings = JSON.parse(this.getAttribute("grid-settings"));
        
        this.customStyle = this.getAttribute("custom-style");

        console.log(this.gridSettings)
        
        
    }

    connectedCallback() {
        if(this.customStyle == "true"){
        // this.style.gridRow = `${this.gridSettings.gridRowStart} / span ${this.gridSettings.rowSpan}`;
        // this.style.gridColumn = `${this.gridSettings.gridColumnStart} / span ${this.gridSettings.colSpan}`;
        //this.style.gridTemplateColumns = `${this.gridSettings.gridTemplateColumns}`;
        
        this.style.gridTemplateColumns = "1fr 1fr";
        //this.getRootNode().host.style.gridTemplateColumns = "1fr 1fr";
        }
        this.render();
    }

    render(){

        this.shadowRoot.innerHTML = `
            <style>
                :host{
                    display: grid;
                    grid-template-columns: 1fr 160px;
                    column-gap: 20px;
                    width: 100%;
                    min-width: 0;
                    box-sizing: border-box;
                    max-height: max-content;
                    
                }
                img{
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }
            </style>
            <slot></slot>
            `;
    }
}

customElements.define("product-image-container", ProductImageContainer);

class variantsItemContainer extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.shadowRoot.innerHTML = `
        <style>
          :host {
            display: grid;
            grid-template-columns: repeat(4,1fr);
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 1.5rem;
            grid-template-columns: repeat(3, 1fr);
            min-width: 100%;
            scrollbar-width: none;
          }
            
        
        </style>
        <slot></slot>
      `;
    }
}

customElements.define("variants-item-container", variantsItemContainer);

class variantItems extends HTMLElement {
    constructor() {
      super();
      //console.log("variantItems", this.querySelector(":host"));
      this.attachShadow({ mode: "open" });
      this.shadowRoot.innerHTML = `
       <style>
        ::slotted(img) {
          width: 100%;
          height: 100%;
          object-fit: cover;
          cursor: pointer;
          aspect-ratio: .75;
          object-position: center;
        }
        .items-container{
          display: flex;
          justify-content: space-between;
          flex-direction: column;
        }
      </style>
        <div class="items-container">
            <slot></slot>
        </div>
      `;
    }
}

customElements.define("variant-items", variantItems);

class VariantsModal extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.title = this.getAttribute("title");
      this.shadowRoot.innerHTML = `
        <style>
          :host{
                display: block;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                z-index: 999;
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease-out, visibility 0.3s ease-out;
            }

            :host([open]){
                grid-template-columns: repeat(4,1fr);
                grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
                gap: .85em;
                opacity: 1;
                visibility: visible;
                transition: opacity 0.3s ease-in, visibility 0.3s ease-in;
            }
            :slotted([data-product-group-container]){
                display: flex;
                justify-content: space-between;
                overflow-x: hidden;
                width: 100%;
                max-width: 1400px;
                column-gap: 2rem;
            }
            div[data-modal-container]{
                position: absolute;
                right: 0;
                background: #fff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
                width: 100%;
                max-width: 375px;
                height: 100%;
                min-height: 100vh;
                overflow-y: auto;
                transform: translateX(100%);
                transition: transform 0.3s ease-out;
                scrollbar-width: none;
                
            }
                
            :host([open]) div[data-modal-container] {
                transform: translateX(0);
            }

            button{
                color: #fff;
                border: none;
                cursor: pointer;
                position: absolute;
                top: 0;
                right: 0;
                z-index: 999;
                background: transparent;
                padding: 0;
                margin: 0;
                position: relative;
            }
            [data-modal-header-content]{
              
              display: flex;
              position: relative;
              justify-content: space-between;
              align-items: center;
              height: 100%;
              max-height: 40px;
            }
            [data-filter-search]{
                display: flex;
                align-items: center;
                width: auto;
                height: 100%;
                gap: 1rem;
            }
            [data-content-container]{
                display: flex;
                justify-content: space-between;
                overflow-x: hidden;
                width: 100%;
                column-gap: 2rem;
                scrollbar-width: none;
                overflow-x: hidden;
                transform: translateX(calc(-100% - 2rem));
                transform: translateX(0%);
            }
        </style>
        <div data-modal-container>
            <div data-modal-header-content>
                <div data-filter-search>
                  <button type="button">
                    <svg class="" width="21" height="21" viewBox="0 0 24 24" fill="none">
                    <path class="group-hover:stroke-black-600" d="M10.3636 3C8.90722 3 7.48354 3.43187 6.2726 4.24099C5.06167 5.05011 4.11786 6.20015 3.56052 7.54567C3.00319 8.89119 2.85737 10.3718 3.14149 11.8002C3.42562 13.2286 4.12693 14.5406 5.15675 15.5704C6.18657 16.6003 7.49863 17.3016 8.92703 17.5857C10.3554 17.8698 11.836 17.724 13.1815 17.1667C14.527 16.6093 15.6771 15.6655 16.4862 14.4546C17.2953 13.2437 17.7272 11.82 17.7272 10.3636C17.7271 8.41069 16.9512 6.5378 15.5703 5.15688C14.1894 3.77597 12.3165 3.00012 10.3636 3Z" stroke="#121212" stroke-width="1.5" stroke-miterlimit="10"></path><path d="M15.8574 15.8574L21.0001 21.0001" stroke="#121212" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"></path></svg>
                  </button>
                  <button type="button">
                  <svg class="" width="22" height="22" viewBox="0 0 20 20" fill="none"><path class="group-hover:fill-black-600" fill-rule="evenodd" clip-rule="evenodd" d="M5.91764 6.45832C5.91764 5.60688 6.60787 4.91666 7.45931 4.91666C8.31075 4.91666 9.00098 5.60688 9.00098 6.45832C9.00098 7.30976 8.31075 7.99999 7.45931 7.99999C6.60787 7.99999 5.91764 7.30976 5.91764 6.45832ZM4.51079 7.20824H2.5C2.08579 7.20824 1.75 6.87246 1.75 6.45824C1.75 6.04403 2.08579 5.70824 2.5 5.70824H4.51083C4.84488 4.39111 6.0383 3.41666 7.45931 3.41666C8.88033 3.41666 10.0738 4.39112 10.4078 5.70826H17.4997C17.9139 5.70826 18.2497 6.04404 18.2497 6.45826C18.2497 6.87247 17.9139 7.20826 17.4997 7.20826H10.4078C10.0738 8.52546 8.88038 9.49999 7.45931 9.49999C6.03824 9.49999 4.84478 8.52546 4.51079 7.20824ZM11.9176 13.1248C11.9176 12.2734 12.6079 11.5832 13.4593 11.5832C14.3108 11.5832 15.001 12.2734 15.001 13.1248C15.001 13.9763 14.3108 14.6665 13.4593 14.6665C12.6079 14.6665 11.9176 13.9763 11.9176 13.1248ZM13.4593 10.0832C12.0382 10.0832 10.8448 11.0577 10.5108 12.3749H2.5C2.08579 12.3749 1.75 12.7107 1.75 13.1249C1.75 13.5391 2.08579 13.8749 2.5 13.8749H10.5108C10.8449 15.192 12.0383 16.1665 13.4593 16.1665C14.8803 16.1665 16.0738 15.192 16.4078 13.8749H17.4996C17.9138 13.8749 18.2496 13.5391 18.2496 13.1249C18.2496 12.7107 17.9138 12.3749 17.4996 12.3749H16.4078C16.0738 11.0577 14.8804 10.0832 13.4593 10.0832Z" fill="#121212"></path></svg>
                  </button>
                </div>
                <span data-title>${this.title}</span>
                <button type="button" data-close-button class="modal-popup__close">
                  <svg class="" width="11" height="11" viewBox="0 0 20 20" fill="none">
                  <path d="M18.75 18.75L1.25 1.25M18.75 1.25L1.25 18.75" stroke="#121212" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </button>
              </div>
          <!-- <h2>${this.title}</h2> -->
          <div data-content-container>
            <slot name="variant-items"></slot>
            <slot name="quick-view"></slot>
          </div>

        </div>
      `;

      this.shadowRoot.querySelector("button[data-close-button]").addEventListener("click", () => {
        
        //const toggle = Array.from(document.querySelectorAll("product-group")).find(product => product.shadowRoot.querySelector('[remove]'))
        //toggle.shadowRoot.querySelector("[data-toggle]").removeAttribute("remove");
        this.removeAttribute("open");
    });

    // this.shadowRoot.addEventListener("product-picker-quick-view-open", (e) => {
    //     const product = e.detail.product;
    //     const quickView = document.createElement("product-picker-quick-view");
    //     quickView.setAttribute("product", JSON.stringify(product));
    //     this.shadowRoot.querySelector("[data-content-container]").appendChild(quickView);
   
    // });
}

  /* add observe attributes */
    static get observedAttributes() {
      return ["open","title"];
    }
    attributeChangedCallback(name, oldValue, newValue) {
      if(name === "title"){
        this.shadowRoot.querySelector("[data-title]").textContent = newValue;
      }
      
    }
}

customElements.define("variants-modal", VariantsModal);

// First, let's create a base class for shared functionality
class BaseComponent extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
    }
  
    dispatch(eventName, detail) {
      this.dispatchEvent(new CustomEvent(eventName, {
        bubbles: true,
        composed: true,
        detail
      }));
    }
  }
  
  // ProductPickerQuickView Component
  class ProductPickerQuickView extends BaseComponent {
    static get observedAttributes() {
      return ['show-star-rating', 'open'];
    }
  
    constructor() {
      super();
      
      this.state = {
        locale: {
          quick_view_button_label: 'Select this design'
        }
      };
    }
  
    get styles() {
      return `
        <style>
          :host {
            display: block;
            min-width: 100%;
            width: 100%;
          }
          :host[open] {
            overflow-x: visible;
            transform: translateX(calc(-100% - 2rem));
        }

          
          .aspect-product-gallery {
            
            position: relative;
          }
          
          .info-section {
            margin: 12px 0 16px;
            height: fit-content;
          }
          
          .product-title {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            font-weight: 500;
          }
          
          .product-description {
            margin: 1rem 0;
            font-size: 14px;
          }
          
          .cta-button {
            width: 100%;
            margin-top: 24px;
            padding: 8px;
            font-size: 18px;
            text-transform: capitalize;
            background: black;
            color: white;
            border: none;
            cursor: pointer;
            position: relative;
          }
          
          .cta-button::before {
            content: '+';
            position: absolute;
            left: 1rem;
          }
          .quick-view-container {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
          }
          
          /* Add any additional styles needed */
        </style>
      `;
    }
  
    connectedCallback() {
      this.product = JSON.parse(this.getAttribute('product') || '{}');
      this.showStarRating = this.hasAttribute('show-star-rating');
      this.render();
      this.attachEventListeners();
    }
  
    attributeChangedCallback(name, oldValue, newValue) {
      if (oldValue === newValue) return;
      
      if (name === 'show-star-rating') {
        this.showStarRating = newValue !== null;
        this.render();
      }

      if(name === "open"){
        const variantsModal = document.querySelector("variants-modal");
        if(this.hasAttribute("open")){
            console.log("Product", this.getAttribute('product'));
            this.product = JSON.parse(this.getAttribute('product') || '{}');
            variantsModal.shadowRoot.querySelector("[data-content-container]").style.transform = "translateX(calc(-100% - 2rem))";
            variantsModal.shadowRoot.querySelector("[data-content-container]").style.overflowX = "visible";
            setTimeout(()=>this.render(), 0);
        } else {
            variantsModal.shadowRoot.querySelector("[data-content-container]").style.transform = "translateX(100%)";
            variantsModal.shadowRoot.querySelector("[data-content-container]").style.overflowX = "hidden";
        }
      }

    }
  
    render() {
      this.shadowRoot.innerHTML = `
        ${this.styles}
        <div class="quick-view-container">
          <div class="aspect-product-gallery">
            <product-picker-quick-view-gallery
              media='${JSON.stringify(this.product.media)}'
              first-image-index="${this.product.quick_view_first_image_index || 0}"
              show-arrows
            >
            </product-picker-quick-view-gallery>
          </div>
          
          <div class="info-section">
            ${this.product.title ? 
              `<h1 class="product-title">${this.product.title}</h1>` : 
              ''}
            
            ${this.product.description ? 
              `<p class="product-description">${this.product.description}</p>` : 
              ''}
            
            ${this.showStarRating && this.product.stamped_badge ? 
              `<div class="rating-badge">${this.product.stamped_badge}</div>` : 
              ''}
          </div>
          
          <button class="cta-button">
            ${this.state.locale.quick_view_button_label}
          </button>
        </div>
      `;
    }
  
    renderTags() {
      // Implement tag rendering logic here
      return `
        ${this.product.tags?.map(tag => `<span class="tag">${tag}</span>`).join('') || ''}
        ${!this.product.available ? '<span class="tag sold-out">Sold Out</span>' : ''}
      `;
    }
  
    attachEventListeners() {
      this.shadowRoot.querySelector('.cta-button')?.addEventListener('click', () => {
        this.dispatch('design-selected', { product: this.product });
      });
    }
  }
  
  // ProductPickerQuickViewGallery Component
  class ProductPickerQuickViewGallery extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.splide = null;
      
    }

    
    static get observedAttributes() {
      return ['media', 'first-image-index', 'show-arrows'];
    }
  
    async connectedCallback() {
      // Load dependencies first
      //await this.loadDependencies();
      await this.loadSplideJS();
      // Then render and initialize
      this.render();

      this.shadowRoot.querySelector('[data-qv-close]').addEventListener('click',()=>{
        console.log("Root Node", this.getRootNode());
        this.getRootNode().host.removeAttribute('open');
        document.querySelector('variants-modal').shadowRoot.querySelector('[data-content-container]').style.transform = "translateX(0%)";
        //this.removeAttribute('open');
    });      
      
      // Wait a tick for DOM to be ready

      setTimeout(() => this.initializeSplide(), 0);
    }
  

    // async loadDependencies() {
    //   await Promise.all([
    //     this.loadSplideCSS(),
    //     this.loadSplideJS()
    //   ]);
    // }
  
    async loadSplideCSS() {
      // Only load CSS if not already loaded
      if (!document.querySelector('#splide-css')) {
        const linkPromise = new Promise((resolve, reject) => {
          const link = document.createElement('link');
          link.id = 'splide-css';
          link.rel = 'stylesheet';
          link.href = 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css';
          link.onload = resolve;
          link.onerror = reject;
          document.head.appendChild(link);
        });
        
        try {
          await linkPromise;
          console.log('Splide CSS loaded');
        } catch (error) {
          console.error('Failed to load Splide CSS:', error);
        }
      }
    }
  
    async loadSplideJS() {
      // Only load JS if not already loaded
      if (!window.Splide) {
        const scriptPromise = new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js';
          script.onload = resolve;
          script.onerror = reject;
          document.head.appendChild(script);
        });
  
        try {
          await scriptPromise;
          console.log('Splide JS loaded');
        } catch (error) {
          console.error('Failed to load Splide JS:', error);
        }
      }
    }
  
    get styles() {
        return `
          <style>
            :host {
              display: block;
              position: relative;
              width: 100%;
              height: 100%;
            }
            
            .gallery-container {
              width: 100%;
              height: 100%;
            }
    
            /* Essential Splide structure styles */
            .splide {
              width: 100%;
              height: 100%;
              position: relative;
            }
    
            .splide__track {
              width: 100%;
              height: 100%;
              position: relative;
              overflow: hidden;
            }
    
            .splide__list {
              display: flex;
              height: 100%;
              margin: 0;
              padding: 0;
              list-style: none;
              backface-visibility: hidden;
              transform-style: preserve-3d;
              touch-action: pan-y;
            }
    
            .splide__slide {
              width: 100%;
              height: 100%;
              flex-shrink: 0;
              position: relative;
            }
    
            .media-item {
              width: 100%;
              height: auto;
              object-fit: cover;
              display: block;
              aspect-ratio: 343 / 537;
            }
    
            /* Navigation arrows */
            .splide__arrows {
              position: absolute;
              top: 50%;
              transform: translateY(-50%);
              width: 100%;
              z-index: 5;
              pointer-events: none;
            }
    
            .splide__arrow {
              position: absolute;
              top: 50%;
              transform: translateY(-50%);
              width: 40px;
              height: 40px;
              background: white;
              border: none;
              border-radius: 50%;
              cursor: pointer;
              padding: 12px;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
              pointer-events: auto;
            }
    
            .splide__arrow--prev {
              left: 12px;
            }
    
            .splide__arrow--next {
              right: 12px;
            }
    
            /* Pagination */
            .splide__pagination {
              position: absolute;
              bottom: 20px;
              left: 50%;
              transform: translateX(-50%);
              display: flex;
              gap: 8px;
              z-index: 5;
              list-style: none;
              padding: 0;
              margin: 0;
            }
    
            .splide__pagination__page {
              width: 8px;
              height: 8px;
              background: rgba(0, 0, 0, 0.3);
              border: none;
              border-radius: 50%;
              cursor: pointer;
              transition: all 0.3s ease;
            }
    
            .splide__pagination__page.is-active {
              background: rgba(0, 0, 0, 0.9);
              transform: scale(1.2);
            }
    
            .tags-container {
              position: absolute;
              top: 10px;
              left: 10px;
              z-index: 10;
            }
            .quick-view-header{
              padding-block: 1rem;
              display: flex;
              justify-content: space-between;
              align-items: center;
            }
            .quick-view-heading-text{
              position: absolute;
              left: 50%;
              transform: translate(-50%);
            }
          </style>
        `;
    }
  
    render() {
      const media = JSON.parse(this.getAttribute('media') || '[]');
      const showArrows = this.hasAttribute('show-arrows');
  
      this.shadowRoot.innerHTML = `
        ${this.styles}
        <div class="quick-view-header">
            <button type="button" data-qv-close>
                <svg height="14" width="15" class="" viewBox="0 0 18 16" fill="none">
                    <path d="M8.4375 14.75L1.6875 8L8.4375 1.25M2.625 8H16.3125" stroke="#121212" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </button>
            <span class="quick-view-heading-text">Quick View</span>
        </div>
        <div class="gallery-container">
          <div class="splide">
            <div class="splide__track">
              <ul class="splide__list">
                ${media.map(item => `
                  <li class="splide__slide">
                    ${item.media_type === 'image' ? 
                      `<img 
                        class="media-item" 
                        src="${item.src}" 
                        alt="${item.alt || ''}"
                        loading="lazy"
                      />` : 
                      `<video 
                        class="media-item" 
                        src="${item.sources?.[0]?.url}" 
                        autoplay 
                        loop 
                        muted
                        playsinline
                      ></video>`
                    }
                  </li>
                `).join('')}
              </ul>
            </div>
            
            ${showArrows && media.length > 1 ? `
              <div class="splide__arrows">
                <button class="splide__arrow splide__arrow--prev" type="button">
                  <svg width="12" height="12" viewBox="0 0 12 12">
                    <path d="M8 1L3 6L8 11" stroke="currentColor" fill="none"/>
                  </svg>
                </button>
                <button class="splide__arrow splide__arrow--next" type="button">
                  <svg width="12" height="12" viewBox="0 0 12 12">
                    <path d="M4 1L9 6L4 11" stroke="currentColor" fill="none"/>
                  </svg>
                </button>
              </div>
  
              <div class="splide__pagination"></div>
            ` : ''}
          </div>
          
          <div class="tags-container">
            <slot name="tags"></slot>
          </div>
        </div>
      `;
    }
  
    initializeSplide() {
      if (!window.Splide) {
        console.error('Splide not loaded');
        return;
      }
      
      const splideElement = this.shadowRoot.querySelector('.splide');
      if (!splideElement) {
        console.error('Splide element not found');
        return;
      }
  
      const firstImageIndex = parseInt(this.getAttribute('first-image-index')) || 0;
      const media = JSON.parse(this.getAttribute('media') || '[]');
  
      try {
        if (this.splide) {
          this.splide.destroy();
        }
  
        this.splide = new window.Splide(splideElement, {
          type: 'slide',
          arrows: media.length > 1,
          pagination: true,
          start: firstImageIndex,
          mediaQuery: 'min',
          classes: {
            arrows: 'splide__arrows',
            arrow: 'splide__arrow',
            prev: 'splide__arrow--prev',
            next: 'splide__arrow--next',
            pagination: 'splide__pagination',
            page: 'splide__pagination__page'
          },
          height: '100%'
        });
  
        this.splide.mount();
        console.log('Splide initialized');
      } catch (error) {
        console.error('Failed to initialize Splide:', error);
      }
    }
  
    disconnectedCallback() {
      if (this.splide) {
        this.splide.destroy();
        this.splide = null;
      }
    }
  
    attributeChangedCallback(name, oldValue, newValue) {
      if (oldValue === newValue) return;
      
      // Re-render and reinitialize when media changes
      if (name === 'media' || name === 'first-image-index') {
        this.render();
        setTimeout(() => this.initializeSplide(), 0);
      }
    }
  }
  
  // Register the component
  
  
  // Register the custom elements
  customElements.define('product-picker-quick-view', ProductPickerQuickView);
  customElements.define('product-picker-quick-view-gallery', ProductPickerQuickViewGallery);
  

  class ProductVariantPicker extends HTMLElement
  {
    constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.shadowRoot.innerHTML = `
        <style>
          :host {
            display: block;
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1rem;
          }
        </style>
        <slot></slot>
      `;
    }
  }

  customElements.define("product-variant-picker", ProductVariantPicker);
  
  // Usage Example:
  /*
  <product-picker-quick-view
    show-star-rating
    product='{
      "media": [
        {
          "id": "1",
          "media_type": "image",
          "src": "product1.jpg",
          "alt": "Product 1"
        },
        {
          "id": "2",
          "media_type": "video",
          "sources": [{"url": "product-video.mp4"}]
        }
      ],
      "quick_view_first_image_index": 0,
      "title": "Product Title",
      "description": "Product description here",
      "available": true,
      "price": "99.99",
      "compare_at_price": "149.99",
      "tags": ["new", "sale"],
      "stamped_badge": "<div class=\"stamped-badge\">★★★★★</div>"
    }'
  ></product-picker-quick-view>
  
  // JavaScript
  document.querySelector('product-picker-quick-view')
    .addEventListener('design-selected', (e) => {
      console.log('Selected product:', e.detail.product);
    });
  */